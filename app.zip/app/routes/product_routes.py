from flask import Blueprint, request, jsonify
from app.models.product import Product
from app.schemas.product_schema import ProductSchema
from app.services.predictor import predict_demand
from app import db

product_bp = Blueprint('products', __name__)
schema = ProductSchema()

# CREATE
@product_bp.route('/products', methods=['POST'])
def add_product():
    data = request.json
    errors = schema.validate(data)

    if errors:
        return jsonify(errors), 400

    product = Product(**data)
    db.session.add(product)
    db.session.commit()

    return jsonify(schema.dump(product))


# READ
@product_bp.route('/products', methods=['GET'])
def get_products():
    products = Product.query.all()
    return jsonify(schema.dump(products, many=True))


# DELETE
@product_bp.route('/products/<int:id>', methods=['DELETE'])
def delete_product(id):
    product = Product.query.get(id)

    if not product:
        return {"error": "Not found"}, 404

    db.session.delete(product)
    db.session.commit()

    return {"message": "Deleted"}


# PREDICT
@product_bp.route('/predict/<int:id>', methods=['GET'])
def predict(id):
    product = Product.query.get(id)

    if not product:
        return {"error": "Product not found"}, 404

    sales_history = [product.sales - 5, product.sales - 2, product.sales]
    prediction = predict_demand(sales_history)

    return {"predicted_demand": prediction}