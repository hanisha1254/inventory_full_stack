import numpy as np
from sklearn.linear_model import LinearRegression

def predict_demand(sales_history):
    X = np.array(range(len(sales_history))).reshape(-1, 1)
    y = np.array(sales_history)

    model = LinearRegression()
    model.fit(X, y)

    future = np.array([[len(sales_history)]])
    prediction = model.predict(future)

    return int(prediction[0])