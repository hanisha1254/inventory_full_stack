from marshmallow import Schema, fields

class ProductSchema(Schema):
    id = fields.Int(dump_only=True)
    name = fields.Str(required=True)
    stock = fields.Int(required=True)
    price = fields.Float(required=True)
    sales = fields.Int(required=True)