import React, { useEffect, useState } from "react";

function App() {
  const [products, setProducts] = useState([]);
  const [prediction, setPrediction] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [form, setForm] = useState({
    name: "",
    stock: "",
    price: "",
    sales: ""
  });

  const fetchProducts = () => {
    setLoading(true);
    fetch("http://127.0.0.1:5000/products")
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load data");
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const predict = async (id) => {
    const res = await fetch(`http://127.0.0.1:5000/predict/${id}`);
    const data = await res.json();
    setPrediction(prev => ({ ...prev, [id]: data.predicted_demand }));
  };

  const deleteProduct = async (id) => {
    await fetch(`http://127.0.0.1:5000/products/${id}`, {
      method: "DELETE"
    });
    fetchProducts();
  };

  const handleSubmit = async () => {
    if (!form.name || !form.stock || !form.price || !form.sales) {
      alert("Fill all fields");
      return;
    }

    await fetch("http://127.0.0.1:5000/products", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: form.name,
        stock: Number(form.stock),
        price: Number(form.price),
        sales: Number(form.sales)
      })
    });

    setForm({ name: "", stock: "", price: "", sales: "" });
    fetchProducts();
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>📦 Inventory Dashboard</h1>

      {/* FORM */}
      <div style={styles.formCard}>
        <h2>Add Product</h2>
        <div style={styles.formGrid}>
          <input placeholder="Name" value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })} />

          <input type="number" placeholder="Stock" value={form.stock}
            onChange={e => setForm({ ...form, stock: e.target.value })} />

          <input type="number" placeholder="Price" value={form.price}
            onChange={e => setForm({ ...form, price: e.target.value })} />

          <input type="number" placeholder="Sales" value={form.sales}
            onChange={e => setForm({ ...form, sales: e.target.value })} />
        </div>

        <button style={styles.primaryBtn} onClick={handleSubmit}>
          ➕ Add Product
        </button>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* PRODUCTS */}
      <div style={styles.grid}>
        {products.map(p => (
          <div key={p.id} style={styles.card}>
            <h3>{p.name}</h3>
            <p>📦 Stock: {p.stock}</p>
            <p>💰 Price: ₹{p.price}</p>

            <button style={styles.secondaryBtn}
              onClick={() => predict(p.id)}>
              Predict
            </button>

            <button style={styles.deleteBtn}
              onClick={() => deleteProduct(p.id)}>
              Delete
            </button>

            {prediction[p.id] && (
              <p style={styles.prediction}>
                📈 Predicted: {prediction[p.id]}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  container: { padding: "30px", background: "#f5f7fa", minHeight: "100vh" },
  title: { textAlign: "center" },

  formCard: {
    background: "white",
    padding: "20px",
    borderRadius: "10px",
    marginBottom: "20px"
  },

  formGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2,1fr)",
    gap: "10px"
  },

  grid: {
    display: "flex",
    flexWrap: "wrap",
    gap: "20px"
  },

  card: {
    background: "white",
    padding: "15px",
    borderRadius: "10px",
    width: "250px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
  },

  primaryBtn: {
    background: "green",
    color: "white",
    padding: "10px",
    border: "none"
  },

  secondaryBtn: {
    background: "blue",
    color: "white",
    padding: "8px",
    marginTop: "10px",
    border: "none"
  },

  deleteBtn: {
    background: "red",
    color: "white",
    padding: "8px",
    marginTop: "5px",
    border: "none"
  },

  prediction: {
    marginTop: "10px",
    color: "green",
    fontWeight: "bold"
  }
};

export default App;